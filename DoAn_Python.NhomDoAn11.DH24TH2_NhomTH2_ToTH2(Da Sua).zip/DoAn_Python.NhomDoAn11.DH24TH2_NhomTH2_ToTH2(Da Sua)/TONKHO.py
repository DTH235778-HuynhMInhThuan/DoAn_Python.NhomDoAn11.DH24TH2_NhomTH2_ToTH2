import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from db import connect_db
import pandas as pd  

def tao_frame_tonkho(root, show_home):
    frame_tk = tk.Frame(root)
    frame_tk.pack(fill="both", expand=True)

    # ====== HÀM HIỂN THỊ TỒN KHO ======
    def hien_tonkho():
        # Xóa dữ liệu cũ trên cây
        for row in tree_tk.get_children():
            tree_tk.delete(row)
        
        try:
            conn = connect_db()
            cursor = conn.cursor()

            # Lấy hãng xe được chọn từ combobox
            hang_xe_chon = combo_hangxe_filter.get()

            # Câu truy vấn SQL
            query = """
                SELECT 
                    x.MaXe, 
                    x.TenXe, 
                    x.HangXe, 
                    x.SoLuong AS SoLuongGoc, 
                    IFNULL(SUM(h.SoLuong), 0) AS TongDaBan
                FROM XeMay x
                LEFT JOIN HoaDon h ON x.MaXe = h.MaXe
            """
            
            # Xử lý lọc theo hãng
            params = ()
            if hang_xe_chon and hang_xe_chon != "Tất cả":
                query += " WHERE x.HangXe = %s"
                params = (hang_xe_chon,)
            
            query += " GROUP BY x.MaXe, x.TenXe, x.HangXe, x.SoLuong"

            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Tính tồn kho và hiển thị
            for row in rows:
                ma_xe, ten_xe, hang_xe, sl_goc, da_ban = row
                ton_kho = sl_goc - int(da_ban)
                
                # Insert vào Treeview
                tree_tk.insert("", tk.END, values=(ma_xe, ten_xe, hang_xe, sl_goc, int(da_ban), ton_kho))

            conn.close()
        except Exception as e:
            messagebox.showerror("Lỗi", str(e))

   
    def xuat_excel():
        # Kiểm tra xem có dữ liệu không
        if len(tree_tk.get_children()) < 1:
            messagebox.showwarning("Thông báo", "Không có dữ liệu để xuất!")
            return

        # Mở hộp thoại chọn nơi lưu file
        file_path = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")],
            title="Lưu file Excel"
        )

        if not file_path: # Nếu người dùng nhấn Cancel
            return

        try:
            # Lấy toàn bộ dữ liệu đang hiển thị trên Treeview
            data = []
            columns = ["Mã xe", "Tên xe", "Hãng xe", "Số lượng gốc", "Đã bán", "Tồn kho"]
            
            for item in tree_tk.get_children():
                # Lấy giá trị của từng dòng
                row_values = tree_tk.item(item)['values']
                data.append(row_values)

            # Tạo DataFrame từ dữ liệu và xuất ra Excel
            df = pd.DataFrame(data, columns=columns)
            df.to_excel(file_path, index=False) # index=False để không in số thứ tự dòng (0,1,2...)

            messagebox.showinfo("Thành công", f"Đã xuất file thành công tại:\n{file_path}")
        except Exception as e:
            messagebox.showerror("Lỗi", f"Không thể xuất file: {str(e)}")

    # ====== GIAO DIỆN ======
    
    # --- Tiêu đề ---
    tk.Label(frame_tk, text="QUẢN LÝ TỒN KHO", font=("Arial", 16, "bold"), fg="#2c3e50").pack(pady=10)

    # --- Bộ lọc ---
    filter_frame = tk.Frame(frame_tk)
    filter_frame.pack(pady=10)

    tk.Label(filter_frame, text="Lọc theo hãng:", font=("Arial", 11)).grid(row=0, column=0)
    
    # Lấy danh sách hãng xe để đưa vào Combobox
    ds_hang = ["Tất cả"]
    try:
        conn = connect_db()
        cur = conn.cursor()
        cur.execute("SELECT DISTINCT HangXe FROM XeMay")
        for r in cur.fetchall():
            ds_hang.append(r[0])
        conn.close()
    except:
        pass

    combo_hangxe_filter = ttk.Combobox(filter_frame, values=ds_hang, state="readonly", width=15)
    combo_hangxe_filter.current(0) # Chọn mặc định là "Tất cả"
    combo_hangxe_filter.grid(row=0, column=1, padx=10)
    combo_hangxe_filter.bind("<<ComboboxSelected>>", lambda e: hien_tonkho())

    # --- Frame chứa các nút chức năng ---
    btn_frame = tk.Frame(frame_tk)
    btn_frame.pack(pady=5)
    
    btn_font = ("Arial", 10, "bold")
    
    
    tk.Button(btn_frame, text="Xuất Excel", command=xuat_excel,
              bg="#217346", fg="white", font=btn_font, width=12, pady=5, relief="flat"
              ).grid(row=0, column=0, padx=5)

   
    tk.Button(btn_frame, text="Quay lại", command=lambda:[frame_tk.pack_forget(), show_home()],
              bg="#f39c12", fg="white", font=btn_font, width=12, pady=5, relief="flat"
              ).grid(row=0, column=1, padx=5)

    # --- Bảng Treeview hiển thị tồn kho ---
    tree_frame = tk.Frame(frame_tk)
    tree_frame.pack(fill="both", expand=True, padx=20, pady=10)

    cols = ("Mã xe", "Tên xe", "Hãng xe", "Số lượng gốc", "Đã bán", "Tồn kho")
    tree_tk = ttk.Treeview(tree_frame, columns=cols, show="headings", height=15)
    
    # Định dạng các cột
    tree_tk.heading("Mã xe", text="Mã Xe")
    tree_tk.column("Mã xe", width=80, anchor="center")
    
    tree_tk.heading("Tên xe", text="Tên Xe")
    tree_tk.column("Tên xe", width=200)
    
    tree_tk.heading("Hãng xe", text="Hãng Xe")
    tree_tk.column("Hãng xe", width=100, anchor="center")
    
    tree_tk.heading("Số lượng gốc", text="SL Nhập")
    tree_tk.column("Số lượng gốc", width=100, anchor="center")

    tree_tk.heading("Đã bán", text="Đã Bán")
    tree_tk.column("Đã bán", width=100, anchor="center")

    tree_tk.heading("Tồn kho", text="Tồn Kho")
    tree_tk.column("Tồn kho", width=100, anchor="center")
    
    # Thanh cuộn
    scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree_tk.yview)
    tree_tk.configure(yscroll=scrollbar.set)
    scrollbar.pack(side="right", fill="y")
    tree_tk.pack(fill="both", expand=True)

    # --- Tải dữ liệu lần đầu ---
    hien_tonkho()
    
    return frame_tk