xe_goi_y = {
    "Honda": {"Wave": 20000000, "Future": 40000000, "Vario": 50000000, "SH": 100000000},
    "Yamaha": {"PG-1": 40000000, "Exciter": 55000000, "Sirius": 23000000},
    "Suzuki": {"Satria": 53000000, "V-Strom 250SX": 132000000}
}